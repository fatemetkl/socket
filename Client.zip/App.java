import com.soc.Client;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.swing.filechooser.*;

public class App extends JFrame{
    private JPanel App_panel;
    private JButton receive;
    private JButton cancleButton;

    public App(){
        //receive.setBounds(400,200,10,10);
        receive.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
                String get_add;
                int returnValue = jfc.showSaveDialog(null);

                if (returnValue == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = jfc.getSelectedFile();
                    System.out.println(selectedFile.getAbsolutePath());
                    get_add = selectedFile.getAbsolutePath();
                    try {
                        new Client(get_add);
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                    //JOptionPane.showConfirmDialog(null, "Success!");
                }
            }
        });
        cancleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);

            }
        });
    }

    public static void main(String [] args){
        JFrame frame = new JFrame("App");
        frame.setBounds(500,200,400,400);
        frame.setLayout(new GridLayout());
        frame.setContentPane(new App().App_panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        }

    }

